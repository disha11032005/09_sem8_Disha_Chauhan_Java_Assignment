/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlTransient;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;

/**
 *
 * @author Disha
 */
@Entity
@Table(name = "product_master")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ProductMaster.findAll", query = "SELECT p FROM ProductMaster p"),
    @NamedQuery(name = "ProductMaster.findByProductId", query = "SELECT p FROM ProductMaster p WHERE p.productId = :productId"),
    @NamedQuery(name = "ProductMaster.findByProductName", query = "SELECT p FROM ProductMaster p WHERE p.productName = :productName"),
    @NamedQuery(name = "ProductMaster.findByPrice", query = "SELECT p FROM ProductMaster p WHERE p.price = :price"),
    @NamedQuery(name = "ProductMaster.findByUnit", query = "SELECT p FROM ProductMaster p WHERE p.unit = :unit"),
    @NamedQuery(name = "ProductMaster.findByDiscount", query = "SELECT p FROM ProductMaster p WHERE p.discount = :discount"),
    @NamedQuery(name = "ProductMaster.findByImage", query = "SELECT p FROM ProductMaster p WHERE p.image = :image"),
    @NamedQuery(name = "ProductMaster.findByStock", query = "SELECT p FROM ProductMaster p WHERE p.stock = :stock")})
public class ProductMaster implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "product_id")
    private Integer productId;
    @Size(max = 100)
    @Column(name = "product_name")
    private String productName;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "price")
    private BigDecimal price;
    @Size(max = 50)
    @Column(name = "unit")
    private String unit;
    @Column(name = "discount")
    private BigDecimal discount;
    @Size(max = 255)
    @Column(name = "image")
    private String image;
    @Column(name = "stock")
    private Integer stock;
    @JoinColumn(name = "category_id", referencedColumnName = "category_id")
    @ManyToOne
    private CategoryMaster categoryId;
    @OneToMany(mappedBy = "productId")
    private Collection<OrderDetails> orderDetailsCollection;

    public ProductMaster() {
    }

    public ProductMaster(Integer productId) {
        this.productId = productId;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public BigDecimal getDiscount() {
        return discount;
    }

    public void setDiscount(BigDecimal discount) {
        this.discount = discount;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }

    public CategoryMaster getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(CategoryMaster categoryId) {
        this.categoryId = categoryId;
    }

    @XmlTransient
    public Collection<OrderDetails> getOrderDetailsCollection() {
        return orderDetailsCollection;
    }

    public void setOrderDetailsCollection(Collection<OrderDetails> orderDetailsCollection) {
        this.orderDetailsCollection = orderDetailsCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (productId != null ? productId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ProductMaster)) {
            return false;
        }
        ProductMaster other = (ProductMaster) object;
        if ((this.productId == null && other.productId != null) || (this.productId != null && !this.productId.equals(other.productId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.ProductMaster[ productId=" + productId + " ]";
    }
    
}
