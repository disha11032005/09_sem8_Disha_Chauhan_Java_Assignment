package servlet;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.util.*;

@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {

protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {

HttpSession session = req.getSession();

HashMap<Integer,Integer> cart = (HashMap<Integer,Integer>) session.getAttribute("cart");

if(cart == null) cart = new HashMap<>();

int pid = Integer.parseInt(req.getParameter("pid"));
int qty = Integer.parseInt(req.getParameter("qty"));

// 🔥 ADD QUANTITY
cart.put(pid, cart.getOrDefault(pid, 0) + qty);

session.setAttribute("cart", cart);

res.sendRedirect("shop.jsp");
}
}