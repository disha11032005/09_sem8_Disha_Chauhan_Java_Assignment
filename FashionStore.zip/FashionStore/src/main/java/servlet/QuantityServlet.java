/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.HashMap;

/**
 *
 * @author Disha
 */
@WebServlet("/QuantityServlet")
public class QuantityServlet extends HttpServlet {

protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {

HttpSession session = req.getSession();

HashMap<Integer,Integer> cart = (HashMap<Integer,Integer>) session.getAttribute("cart");

int pid = Integer.parseInt(req.getParameter("pid"));
String action = req.getParameter("action");

if(action.equals("inc")){
cart.put(pid, cart.get(pid)+1);
}else if(action.equals("dec")){
int qty = cart.get(pid);
if(qty > 1){
cart.put(pid, qty-1);
}else{
cart.remove(pid);
}
}

session.setAttribute("cart", cart);

res.sendRedirect("cart.jsp");
}
}