/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.ArrayList;

/**
 *
 * @author Disha
 */
@WebServlet("/RemoveServlet")
public class RemoveServlet extends HttpServlet {

protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {

HttpSession session = req.getSession();

ArrayList<Integer> cart = (ArrayList<Integer>)session.getAttribute("cart");

int pid = Integer.parseInt(req.getParameter("pid"));

cart.remove(Integer.valueOf(pid));

session.setAttribute("cart", cart);

res.sendRedirect("cart.jsp");
}
}
