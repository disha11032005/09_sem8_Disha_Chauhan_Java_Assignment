package servlet;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.sql.*;
import java.util.*;
import dao.DBConnection;

@WebServlet("/BillServlet")
public class BillServlet extends HttpServlet {

protected void doPost(HttpServletRequest req, HttpServletResponse res)
throws ServletException, IOException {

try {

HttpSession session = req.getSession();
HashMap<Integer,Integer> cart = (HashMap<Integer,Integer>) session.getAttribute("cart");

// 🔴 CHECK CART
if(cart == null || cart.isEmpty()){
res.sendRedirect("cart.jsp");
return;
}

Connection con = DBConnection.getConnection();

ArrayList<String[]> bill = new ArrayList<>();
double total = 0;

// 🔥 LOOP PRODUCTS
for(int pid : cart.keySet()){

int qty = cart.get(pid);

PreparedStatement ps = con.prepareStatement(
"SELECT * FROM product_master WHERE product_id=?");

ps.setInt(1,pid);
ResultSet rs = ps.executeQuery();

if(rs.next()){

String name = rs.getString("product_name");
double price = rs.getDouble("price");
double sub = price * qty;

total += sub;

bill.add(new String[]{
name,
String.valueOf(qty),
String.valueOf(price),
String.valueOf(sub)
});
}
}

// 🔥 SET DATA
req.setAttribute("bill", bill);
req.setAttribute("total", total);

// 🔥 CLEAR CART
session.removeAttribute("cart");

// 🔥 FORWARD
RequestDispatcher rd = req.getRequestDispatcher("bill.jsp");
rd.forward(req, res);

// 🔴 VERY IMPORTANT
return;

} catch(Exception e){
e.printStackTrace();
}
}
}