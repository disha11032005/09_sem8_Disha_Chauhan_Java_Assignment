/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servlet;

import dao.DBConnection;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author Disha
 */
@WebServlet("/AddProduct")
public class AddProduct extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res) {

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO product_master(product_name, price, stock) VALUES (?,?,?)"
            );

            ps.setString(1, req.getParameter("name"));
            ps.setDouble(2, Double.parseDouble(req.getParameter("price")));
            ps.setInt(3, Integer.parseInt(req.getParameter("stock")));
            ps.setString(4, req.getParameter("image"));

            ps.executeUpdate();

            res.sendRedirect("admin.jsp");

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
