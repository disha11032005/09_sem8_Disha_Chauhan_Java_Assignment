/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servlet;

import dao.DBConnection;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author Disha
 */
@WebServlet("/UpdateProduct")
public class UpdateProduct extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res) {

        try {
            Connection con = DBConnection.getConnection();

            int id = Integer.parseInt(req.getParameter("product_id"));
            String name = req.getParameter("name");
            double price = Double.parseDouble(req.getParameter("price"));
            int stock = Integer.parseInt(req.getParameter("stock"));

            PreparedStatement ps = con.prepareStatement(
                "UPDATE product_master SET product_name=?, price=?, stock=? WHERE product_id=?"
            );

            ps.setString(1, name);
            ps.setDouble(2, price);
            ps.setInt(3, stock);
            ps.setInt(4, id);

            ps.executeUpdate();

            res.sendRedirect("admin.jsp?msg=updated");

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
