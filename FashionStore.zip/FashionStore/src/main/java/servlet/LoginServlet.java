package servlet;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.sql.*;
import dao.DBConnection;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {

PrintWriter out = res.getWriter();

try{
Connection con = DBConnection.getConnection();

PreparedStatement ps = con.prepareStatement(
"SELECT * FROM user_master WHERE login_id=? AND password=?");

ps.setString(1, req.getParameter("login"));
ps.setString(2, req.getParameter("password"));

ResultSet rs = ps.executeQuery();

if(rs.next()){
HttpSession session = req.getSession();
session.setAttribute("user", req.getParameter("login"));
res.sendRedirect("shop.jsp");
}else{
out.println("Invalid login");
}

}catch(Exception e){
out.println(e);
}
}
}