package servlet;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.sql.*;
import dao.DBConnection;

@WebServlet("/ForgotServlet")
public class ForgotServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws IOException {

        String login = req.getParameter("login");
        String answer = req.getParameter("answer");

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "SELECT password FROM user_master WHERE login_id=? AND password_answer=?"
            );

            ps.setString(1, login);
            ps.setString(2, answer);

            ResultSet rs = ps.executeQuery();

            PrintWriter out = res.getWriter();

            if (rs.next()) {
                out.println("Your Password: " + rs.getString("password"));
            } else {
                out.println("Wrong Details!");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}