/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servlet;

import dao.DBConnection;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author Disha
 */
@WebServlet("/DeleteProduct")
public class DeleteProduct extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res) {

        try {
            Connection con = DBConnection.getConnection();

            int id = Integer.parseInt(req.getParameter("product_id"));

            PreparedStatement ps = con.prepareStatement(
                "DELETE FROM product_master WHERE product_id=?"
            );

            ps.setInt(1, id);

            ps.executeUpdate();

            res.sendRedirect("admin.jsp?msg=deleted");

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
