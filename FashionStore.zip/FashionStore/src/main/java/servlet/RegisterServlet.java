package servlet;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.sql.*;
import dao.DBConnection;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {

PrintWriter out = res.getWriter();
HttpSession session = req.getSession();

try{
int sessionCap = (int)session.getAttribute("captcha");
int userCap = Integer.parseInt(req.getParameter("captcha"));

if(sessionCap!=userCap){
out.println("Wrong captcha");
return;
}

Connection con = DBConnection.getConnection();

PreparedStatement ps = con.prepareStatement(
"INSERT INTO user_master(username,login_id,password) VALUES(?,?,?)");

ps.setString(1, req.getParameter("username"));
ps.setString(2, req.getParameter("login"));
ps.setString(3, req.getParameter("password"));

ps.executeUpdate();

res.sendRedirect("login.jsp");

}catch(Exception e){
out.println(e);
}
}
}