/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servlet;

import dao.DBConnection;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
/**
 *
 * @author Disha
 */
@WebServlet("/SearchProduct")
public class SearchProduct extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws IOException {

        try {
            Connection con = DBConnection.getConnection();

            String name = req.getParameter("name");

            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM product_master WHERE product_name LIKE ?"
            );

            ps.setString(1, "%" + name + "%");

            ResultSet rs = ps.executeQuery();

            PrintWriter out = res.getWriter();

            out.println("<h2>Search Results</h2>");

            while(rs.next()) {
                out.println("ID: " + rs.getInt("product_id") + "<br>");
                out.println("Name: " + rs.getString("product_name") + "<br>");
                out.println("Price: " + rs.getDouble("price") + "<br>");
                out.println("Stock: " + rs.getInt("stock") + "<br>");
                out.println("<hr>");
            }

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
