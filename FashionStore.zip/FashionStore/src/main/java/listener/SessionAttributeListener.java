package listener;

import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.*;

@WebListener
public class SessionAttributeListener implements HttpSessionAttributeListener {

    public void attributeAdded(HttpSessionBindingEvent event) {
        System.out.println("Added: " + event.getName());
    }

    public void attributeRemoved(HttpSessionBindingEvent event) {
        System.out.println("Removed: " + event.getName());
    }

    public void attributeReplaced(HttpSessionBindingEvent event) {
        System.out.println("Updated: " + event.getName());
    }
}