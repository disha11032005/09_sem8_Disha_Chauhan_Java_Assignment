package listener;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebListener;

@WebListener
public class ContextListener implements ServletContextListener {

    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("Application Started!");
    }

    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("Application Stopped!");
    }
}