package listener;

import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.*;
import java.sql.*;
import dao.DBConnection;

@WebListener
public class SessionListener implements HttpSessionListener {

public void sessionCreated(HttpSessionEvent se){

try{
Connection con = DBConnection.getConnection();

PreparedStatement ps = con.prepareStatement(
"INSERT INTO session_log(session_id) VALUES(?)");

ps.setString(1, se.getSession().getId());
ps.executeUpdate();

}catch(Exception e){}
}
}