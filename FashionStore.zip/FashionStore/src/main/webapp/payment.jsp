<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="container mt-5">

<h2 class="text-center">? Payment</h2>

<form action="BillServlet" method="post" class="col-md-6 offset-md-3">

<label>Card Number</label>
<input type="text" class="form-control mb-2" required>

<label>Name on Card</label>
<input type="text" class="form-control mb-2" required>

<label>CVV</label>
<input type="password" class="form-control mb-2" required>

<label>Payment Mode</label>
<select class="form-control mb-3" name="mode">
<option>Card</option>
<option>UPI</option>
<option>Cash</option>
</select>

<input type="hidden" name="total" value="<%=request.getParameter("total")%>">

<input type="submit" value="Pay Now" class="btn btn-success w-100">

</form>

</body>
</html>