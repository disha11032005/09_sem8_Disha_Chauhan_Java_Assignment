<%
int captcha = (int)(Math.random()*9000)+1000;
session.setAttribute("captcha", captcha);
%>

<html>
<head>
<title>Register</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background: linear-gradient(to right, #ff9966, #ff5e62);
}
.card {
    border-radius: 15px;
}
</style>

</head>

<body>

<div class="container d-flex justify-content-center align-items-center vh-100">

<div class="card p-4 shadow" style="width: 400px;">

<h3 class="text-center mb-3">Register</h3>

<form action="RegisterServlet" method="post">

<div class="mb-2">
<input type="text" name="username" placeholder="Full Name" class="form-control" required>
</div>

<div class="mb-2">
<input type="text" name="login" placeholder="Login ID" class="form-control" required>
</div>

<div class="mb-2">
<input type="password" name="password" placeholder="Password" class="form-control" required>
</div>

<div class="mb-2">
<input type="text" name="question" placeholder="Security Question" class="form-control">
</div>

<div class="mb-2">
<input type="text" name="answer" placeholder="Answer" class="form-control">
</div>

<div class="mb-2">
<input type="email" name="email" placeholder="Email" class="form-control">
</div>

<!-- CAPTCHA -->
<div class="mb-2">
<label>Captcha: <b><%=captcha%></b></label>
<input type="text" name="captcha" class="form-control" placeholder="Enter Captcha" required>
</div>

<input type="submit" value="Register" class="btn btn-dark w-100">

</form>

<div class="text-center mt-3">
<a href="login.jsp">Already have account? Login</a>
</div>

</div>

</div>

</body>
</html>