<%@ page import="java.sql.*,dao.DBConnection" %>
<%@ page contentType="text/html;charset=UTF-8" %>

<html>
<head>
<title>Shop</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background-color: #f5f5f5;
}

.card:hover {
    transform: scale(1.05);
    transition: 0.3s;
}
</style>

</head>

<body>

<!-- 🔥 NAVBAR -->
<nav class="navbar navbar-dark bg-dark px-4">
    <a class="navbar-brand text-white">🛍 Fashion Store</a>

    <div class="ms-auto">
        <a href="shop.jsp" class="btn btn-light">Shop</a>
        <a href="cart.jsp" class="btn btn-warning">Cart</a>
        <a href="logout.jsp" class="btn btn-danger">Logout</a>
    </div>
</nav>

<h2 class="text-center mt-4 text-primary">Explore Products</h2>

<div class="container mt-4">
<div class="row">

<%
Connection con = DBConnection.getConnection();
PreparedStatement ps = con.prepareStatement("SELECT * FROM product_master");
ResultSet rs = ps.executeQuery();

while(rs.next()){
%>

<div class="col-md-4">
<div class="card shadow p-3 mb-4 text-center">

<img src="images/<%=rs.getString("image")%>" height="150">

<h5><%=rs.getString("product_name")%></h5>

<p class="text-success fw-bold">₹ <%=rs.getDouble("price")%></p>

<!-- 🔥 ADD TO CART WITH QUANTITY -->
<form action="CartServlet" method="post">

<input type="hidden" name="pid" value="<%=rs.getInt("product_id")%>">

<label>Qty:</label>

<button type="button" onclick="this.nextElementSibling.stepDown()">-</button>
<input type="number" name="qty" value="1" min="1">
<button type="button" onclick="this.previousElementSibling.stepUp()">+</button>

<input type="submit" value="Add to Cart" class="btn btn-success w-100">

</form>

</div>
</div>

<% } %>

</div>
</div>

</body>
</html>