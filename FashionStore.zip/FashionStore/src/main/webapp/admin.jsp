<html>
<body>
    
    <nav class="navbar navbar-dark bg-dark">
<a class="navbar-brand text-white ms-3">Fashion Store</a>
<a href="shop.jsp" class="btn btn-light">Shop</a>
<a href="cart.jsp" class="btn btn-warning">Cart</a>
<a href="logout.jsp" class="btn btn-danger">Logout</a>
</nav>

<h2>Admin Panel</h2>

<a href="addProduct.jsp">Add Product</a><br>
<a href="update.jsp">Update Product</a><br>
<a href="delete.jsp">Delete Product</a><br>
<a href="search.jsp">Search Product</a><br>

</body>
</html>