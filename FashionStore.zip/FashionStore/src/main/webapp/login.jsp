<html>
<head>
<title>Login</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background: linear-gradient(to right, #4facfe, #00f2fe);
}
.card {
    border-radius: 15px;
}
</style>

</head>

<body>

<div class="container d-flex justify-content-center align-items-center vh-100">

<div class="card p-4 shadow" style="width: 350px;">

<h3 class="text-center mb-3">Login</h3>

<form action="LoginServlet" method="post">

<div class="mb-3">
<label>Login ID</label>
<input type="text" name="login" class="form-control" required>
</div>

<div class="mb-3">
<label>Password</label>
<input type="password" name="password" class="form-control" required>
</div>

<input type="submit" value="Login" class="btn btn-primary w-100">

</form>

<div class="text-center mt-3">
<a href="register.jsp">Create Account</a><br>
<a href="forgot.jsp">Forgot Password?</a>
</div>

</div>

</div>

</body>
</html>