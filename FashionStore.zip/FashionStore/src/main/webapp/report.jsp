<%@ page import="java.sql.*,dao.DBConnection" %>

<html>
<body>
    
    <nav class="navbar navbar-dark bg-dark">
<a class="navbar-brand text-white ms-3">Fashion Store</a>
<a href="shop.jsp" class="btn btn-light">Shop</a>
<a href="cart.jsp" class="btn btn-warning">Cart</a>
<a href="logout.jsp" class="btn btn-danger">Logout</a>
</nav>

<h2>Stock Report</h2>

<table class="table table-bordered table-striped">
<tr>
    <th>Product</th>
    <th>Stock</th>
</tr>

<%
Connection con = DBConnection.getConnection();
PreparedStatement ps = con.prepareStatement("SELECT * FROM product_master");
ResultSet rs = ps.executeQuery();

while(rs.next()){
%>
<tr>
    <td><%= rs.getString("product_name") %></td>
    <td><%= rs.getInt("stock") %></td>
</tr>
<%
}
%>
</table>

<hr>

<h2>Frequent Visitors (>5)</h2>

<%
PreparedStatement ps2 = con.prepareStatement(
    "SELECT username, visits FROM user_master WHERE visits > 5"
);
ResultSet rs2 = ps2.executeQuery();

while(rs2.next()){
%>
    <%= rs2.getString("username") %> - Visits: <%= rs2.getInt("visits") %><br>
<%
}
%>

</body>
</html>