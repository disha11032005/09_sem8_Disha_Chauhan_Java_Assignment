<html>
<body>

<h2>Delete Product</h2>

<form action="DeleteProduct" method="post">
    Product ID: <input type="text" name="product_id"><br>
    <input type="submit" value="Delete">
</form>

</body>
</html>