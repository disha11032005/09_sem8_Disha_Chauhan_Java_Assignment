<html>
<body>

<h2>Search Product</h2>

<form action="SearchProduct" method="get">
    Product Name: <input type="text" name="name"><br>
    <input type="submit" value="Search">
</form>

</body>
</html>