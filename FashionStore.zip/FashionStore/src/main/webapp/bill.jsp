<%@ page import="java.util.*" %>
<%@ page contentType="text/html;charset=UTF-8" %>

<html>
<head>
<title>Invoice</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="container mt-5">

<h2 class="text-center">🧾 Invoice</h2>

<%
ArrayList<String[]> bill = (ArrayList<String[]>)request.getAttribute("bill");

Double totalObj = (Double)request.getAttribute("total");
double total = (totalObj != null) ? totalObj : 0;

if(bill == null){
%>

<h3 style="color:red;">ERROR: Bill not received</h3>

<%
} else {
%>

<table class="table table-bordered text-center mt-4">

<tr class="table-dark">
<th>Product</th>
<th>Qty</th>
<th>Price</th>
<th>Total</th>
</tr>

<%
for(String[] row : bill){
%>

<tr>
<td><%=row[0]%></td>
<td><%=row[1]%></td>
<td>₹ <%=row[2]%></td>
<td>₹ <%=row[3]%></td>
</tr>

<% } %>

</table>

<h3 class="text-end">Grand Total: ₹ <%=total%></h3>

<% } %>

<div class="text-center mt-4">
<a href="shop.jsp" class="btn btn-primary">Continue Shopping</a>
</div>

</body>
</html>