<html>
<body>

<h2>Update Product</h2>

<form action="UpdateProduct" method="post">
    Product ID: <input type="text" name="product_id"><br>
    Name: <input type="text" name="name"><br>
    Price: <input type="text" name="price"><br>
    Stock: <input type="text" name="stock"><br>
    <input type="submit" value="Update">
</form>

</body>
</html>