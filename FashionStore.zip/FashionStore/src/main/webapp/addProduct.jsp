<html>
<body>

<h2>Add Product</h2>

<form action="AddProduct" method="post">
    Name: <input type="text" name="name"><br>
    Price: <input type="text" name="price"><br>
    Stock: <input type="text" name="stock"><br>
    Image Name: <input type="text" name="image">
    <input type="submit" value="Add">
</form>

</body>
</html>