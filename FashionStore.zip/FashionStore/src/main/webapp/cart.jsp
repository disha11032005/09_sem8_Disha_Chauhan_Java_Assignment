<%@ page import="java.util.*,java.sql.*,dao.DBConnection" %>
<%@ page contentType="text/html;charset=UTF-8" %>

<html>
<head>
<title>Your Cart</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background-color: #f5f5f5;
}

.cart-card {
    border-radius: 15px;
    transition: 0.3s;
}
.cart-card:hover {
    transform: scale(1.02);
}

.product-img {
    height: 80px;
    border-radius: 10px;
}
</style>

</head>

<body>

<!-- 🔥 NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4">
    <a class="navbar-brand text-white">🛍 Fashion Store</a>

    <div class="ms-auto">
        <a href="shop.jsp" class="btn btn-light">Shop</a>
        <a href="cart.jsp" class="btn btn-warning">Cart</a>
        <a href="logout.jsp" class="btn btn-danger">Logout</a>
    </div>
</nav>

<div class="container mt-4">

<h2 class="text-primary mb-4">🛒 Your Cart</h2>

<%
HashMap<Integer,Integer> cart = (HashMap<Integer,Integer>)session.getAttribute("cart");
double total = 0;

if(cart == null || cart.isEmpty()){
%>

<!-- EMPTY CART -->
<div class="text-center">
    <h4>Your cart is empty 😢</h4>
    <a href="shop.jsp" class="btn btn-primary mt-3">Continue Shopping</a>
</div>

<%
} else {

Connection con = DBConnection.getConnection();

for(int pid : cart.keySet()){

int qty = cart.get(pid);

PreparedStatement ps = con.prepareStatement(
"SELECT * FROM product_master WHERE product_id=?");

ps.setInt(1,pid);
ResultSet rs = ps.executeQuery();

if(rs.next()){

double price = rs.getDouble("price");
double sub = price * qty;
total += sub;
%>

<!-- 🔥 PRODUCT CARD -->
<div class="card cart-card shadow p-3 mb-3">

<div class="row align-items-center">

<!-- IMAGE -->
<div class="col-md-2">
<img src="images/<%=rs.getString("image")%>" class="product-img">
</div>

<!-- NAME -->
<div class="col-md-3">
<h5><%=rs.getString("product_name")%></h5>
</div>

<!-- PRICE -->
<div class="col-md-2 text-success fw-bold">
₹ <%=price%>
</div>

<!-- QUANTITY -->
<div class="col-md-3">

<a href="QuantityServlet?pid=<%=pid%>&action=dec" class="btn btn-danger">-</a>

<span class="mx-2 fw-bold"><%=qty%></span>

<a href="QuantityServlet?pid=<%=pid%>&action=inc" class="btn btn-success">+</a>

</div>

<!-- SUBTOTAL -->
<div class="col-md-2 fw-bold">
₹ <%=sub%>
</div>

</div>

</div>

<%
}}}
%>

<!-- 🔥 TOTAL + CHECKOUT -->
<% if(cart != null && !cart.isEmpty()){ %>

<div class="card shadow p-4 mt-4">

<h4>Total Amount: <span class="text-success">₹ <%=total%></span></h4>

<form action="payment.jsp" method="post">
<input type="hidden" name="total" value="<%=total%>">

<input type="submit" value="Proceed to Payment" class="btn btn-success mt-3 w-100">
</form>

</div>

<% } %>

</div>

</body>
</html>