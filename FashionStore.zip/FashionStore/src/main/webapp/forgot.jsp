<html>
<body>

<h2>Forgot Password</h2>

<form action="ForgotServlet" method="post">
    Login ID: <input type="text" name="login"><br>
    Security Question: <input type="text" name="question"><br>
    Answer: <input type="text" name="answer"><br>

    <input type="submit" value="Recover">
</form>

</body>
</html>